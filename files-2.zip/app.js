'use strict';

/* =========================================================
   0. STORAGE KEYS & DEMO SEED DATA
   ========================================================= */
const LS_USERS   = 'terrain_users';
const LS_RECORDS = 'terrain_records';
const LS_SESSION = 'terrain_session';

const DEFAULT_USERS = [
  { username: 'enqueteur', password: 'terrain2024', role: 'enqueteur', name: 'Agent de terrain' },
  { username: 'admin',     password: 'admin2024',    role: 'admin',     name: 'Administrateur' }
];

function seedUsers(){
  if (!localStorage.getItem(LS_USERS)){
    localStorage.setItem(LS_USERS, JSON.stringify(DEFAULT_USERS));
  }
}
function getUsers(){ return JSON.parse(localStorage.getItem(LS_USERS) || '[]'); }
function getRecords(){ return JSON.parse(localStorage.getItem(LS_RECORDS) || '[]'); }
function saveRecords(list){ localStorage.setItem(LS_RECORDS, JSON.stringify(list)); }
function getSession(){ return JSON.parse(localStorage.getItem(LS_SESSION) || 'null'); }
function setSession(user){ localStorage.setItem(LS_SESSION, JSON.stringify(user)); }
function clearSession(){ localStorage.removeItem(LS_SESSION); }

seedUsers();

/* =========================================================
   1. TOASTS
   ========================================================= */
function toast(message, isError){
  const stack = document.getElementById('toastStack');
  const el = document.createElement('div');
  el.className = 'toast' + (isError ? ' is-error' : '');
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => el.remove(), 3600);
}

/* =========================================================
   2. VIEW ROUTING
   ========================================================= */
const viewLogin   = document.getElementById('view-login');
const appShell     = document.getElementById('app');
const viewMobile   = document.getElementById('view-mobile');
const viewDesktop  = document.getElementById('view-desktop');
const userLabel    = document.getElementById('userLabel');

function renderRoute(){
  const session = getSession();
  if (!session){
    viewLogin.hidden = false;
    appShell.hidden = true;
    return;
  }
  viewLogin.hidden = true;
  appShell.hidden = false;
  userLabel.textContent = `${session.name} · ${session.role === 'admin' ? 'Administrateur' : 'Enquêteur'}`;

  const isAdmin = session.role === 'admin';
  viewMobile.hidden = isAdmin;
  viewDesktop.hidden = !isAdmin;

  if (isAdmin){
    document.getElementById('settingsAccount').textContent = `${session.name} (${session.username}) — rôle administrateur`;
    refreshAdmin();
  } else {
    renderMyRecords();
  }
  refreshNetworkUI();
}

/* =========================================================
   3. AUTH
   ========================================================= */
const loginForm  = document.getElementById('loginForm');
const loginError = document.getElementById('loginError');

loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('loginUsername').value.trim();
  const password = document.getElementById('loginPassword').value;
  const user = getUsers().find(u => u.username === username && u.password === password);

  if (!user){
    loginError.textContent = navigator.onLine
      ? "Identifiant ou mot de passe incorrect."
      : "Identifiant ou mot de passe incorrect (vérification hors-ligne sur les comptes déjà utilisés ici).";
    loginError.hidden = false;
    return;
  }
  loginError.hidden = true;
  setSession({ username: user.username, role: user.role, name: user.name });
  loginForm.reset();
  renderRoute();
  toast(`Bienvenue, ${user.name}.`);
});

document.querySelectorAll('[data-demo-user]').forEach(btn => {
  btn.addEventListener('click', () => {
    const which = btn.dataset.demoUser;
    const u = DEFAULT_USERS.find(u => u.role === which);
    document.getElementById('loginUsername').value = u.username;
    document.getElementById('loginPassword').value = u.password;
  });
});

document.getElementById('logoutBtn').addEventListener('click', () => {
  clearSession();
  renderRoute();
});

/* =========================================================
   4. NETWORK STATUS + SYNC
   ========================================================= */
const networkBadge     = document.getElementById('networkBadge');
const networkBadgeText = document.getElementById('networkBadgeText');
const pendingCountEl   = document.getElementById('pendingCount');
const syncStatusBadge  = document.getElementById('syncStatusBadge');
const syncStatusText   = document.getElementById('syncStatusText');
const syncLogEl        = document.getElementById('syncLog');

function pendingRecords(){ return getRecords().filter(r => !r.sync); }

function refreshNetworkUI(){
  const online = navigator.onLine;
  [ [networkBadge, networkBadgeText], [syncStatusBadge, syncStatusText] ].forEach(([badge, textEl]) => {
    if (!badge) return;
    badge.classList.toggle('is-offline', !online);
    textEl.textContent = online ? 'En ligne' : 'Hors-ligne';
  });
  const pending = pendingRecords().length;
  pendingCountEl.textContent = pending;
  const sidebarCount = document.getElementById('sidebarRecordCount');
  if (sidebarCount) sidebarCount.textContent = getRecords().length;
}

function logSync(message, ok){
  if (!syncLogEl) return;
  const row = document.createElement('div');
  row.className = 'sync-log__row' + (ok ? ' is-ok' : '');
  const time = new Date().toLocaleTimeString('fr-FR');
  row.innerHTML = `<time>${time}</time><span>${message}</span>`;
  syncLogEl.prepend(row);
}

let isSyncing = false;
function runSync(auto){
  if (isSyncing) return;
  const pending = pendingRecords();
  if (!navigator.onLine){
    toast("Impossible de synchroniser : appareil hors-ligne.", true);
    logSync('Tentative de synchronisation refusée — hors-ligne.', false);
    return;
  }
  if (pending.length === 0){
    if (!auto) toast("Aucune fiche en attente de synchronisation.");
    return;
  }
  isSyncing = true;
  logSync(`Synchronisation ${auto ? 'automatique' : 'manuelle'} de ${pending.length} fiche(s)…`, false);

  // Simulated network round-trip
  setTimeout(() => {
    const all = getRecords();
    all.forEach(r => { r.sync = true; });
    saveRecords(all);
    isSyncing = false;
    refreshNetworkUI();
    logSync(`${pending.length} fiche(s) synchronisée(s) avec succès.`, true);
    toast(`${pending.length} fiche(s) synchronisée(s).`);
    renderMyRecords();
    refreshAdmin();
  }, 900);
}

window.addEventListener('online', () => {
  refreshNetworkUI();
  toast('Connexion rétablie — synchronisation en cours…');
  runSync(true);
});
window.addEventListener('offline', () => {
  refreshNetworkUI();
  toast('Passage en mode hors-ligne. Les fiches seront sauvegardées localement.', true);
});

document.getElementById('syncNowBtn').addEventListener('click', () => runSync(false));
const syncNowBtn2 = document.getElementById('syncNowBtn2');
if (syncNowBtn2) syncNowBtn2.addEventListener('click', () => runSync(false));

/* =========================================================
   5. MOBILE — DYNAMIC SURVEY FORM
   ========================================================= */
document.querySelectorAll('.tabbar__btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tabbar__btn').forEach(b => b.classList.remove('is-active'));
    btn.classList.add('is-active');
    document.querySelectorAll('.mobile-tab').forEach(t => t.classList.remove('is-active'));
    document.getElementById(`mobileTab-${btn.dataset.mobileTab}`).classList.add('is-active');
    if (btn.dataset.mobileTab === 'list') renderMyRecords();
  });
});

// Toggle switches (Oui/Non)
document.querySelectorAll('.switch').forEach(sw => {
  sw.addEventListener('click', (e) => {
    const opt = e.target.closest('.switch__opt');
    if (!opt) return;
    sw.querySelectorAll('.switch__opt').forEach(o => o.classList.remove('is-active'));
    opt.classList.add('is-active');
    if (sw.dataset.name === 'elevage'){
      document.getElementById('animauxField').hidden = opt.dataset.value !== 'Oui';
    }
  });
});
function switchValue(name){
  const active = document.querySelector(`.switch[data-name="${name}"] .switch__opt.is-active`);
  return active ? active.dataset.value : 'Non';
}

// État civil -> nombre d'enfants
document.getElementById('etatCivil').addEventListener('change', (e) => {
  document.getElementById('enfantsField').hidden = e.target.value !== 'Marié(e)';
});

// Élevage -> liste dynamique d'animaux
let animalRowId = 0;
function addAnimalRow(){
  animalRowId++;
  const wrap = document.createElement('div');
  wrap.className = 'animal-row';
  wrap.dataset.rowId = animalRowId;
  wrap.innerHTML = `
    <label class="field"><span class="field__label">Type d'animal</span>
      <input type="text" class="animal-type" placeholder="ex. Vaches"></label>
    <label class="field"><span class="field__label">Quantité</span>
      <input type="number" class="animal-qty" min="0" placeholder="0"></label>
    <button type="button" class="animal-row__remove" title="Retirer">✕</button>`;
  wrap.querySelector('.animal-row__remove').addEventListener('click', () => wrap.remove());
  document.getElementById('animauxList').appendChild(wrap);
}
document.getElementById('addAnimalBtn').addEventListener('click', addAnimalRow);

// GPS capture
const gpsBtn = document.getElementById('gpsBtn');
const gpsResult = document.getElementById('gpsResult');
let capturedGps = null;
gpsBtn.addEventListener('click', () => {
  if (!navigator.geolocation){
    gpsResult.textContent = "La géolocalisation n'est pas prise en charge par cet appareil.";
    return;
  }
  gpsResult.textContent = 'Capture en cours…';
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      capturedGps = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      gpsResult.textContent = `Position : ${capturedGps.lat.toFixed(5)}, ${capturedGps.lng.toFixed(5)}`;
      gpsResult.classList.add('is-set');
    },
    () => {
      gpsResult.textContent = "Position indisponible (autorisation refusée ou signal absent).";
      gpsResult.classList.remove('is-set');
    },
    { enableHighAccuracy: true, timeout: 10000 }
  );
});

// Form submit -> save record locally
const surveyForm = document.getElementById('surveyForm');
surveyForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const fd = new FormData(surveyForm);
  const session = getSession();

  const animaux = [];
  document.querySelectorAll('#animauxList .animal-row').forEach(row => {
    const type = row.querySelector('.animal-type').value.trim();
    const qty = parseInt(row.querySelector('.animal-qty').value, 10) || 0;
    if (type) animaux.push({ type, quantite: qty });
  });

  const now = new Date();
  const record = {
    id: 'F' + now.getTime().toString(36).toUpperCase(),
    timestamp: now.getTime(),
    dateStr: now.toLocaleDateString('fr-FR'),
    nom: fd.get('nom').trim(),
    prenom: fd.get('prenom').trim(),
    nomComplet: `${fd.get('nom').trim()} ${fd.get('prenom').trim()}`,
    age: parseInt(fd.get('age'), 10) || 0,
    pere: fd.get('pere').trim(),
    mere: fd.get('mere').trim(),
    etatCivil: fd.get('etatCivil'),
    nombreEnfants: fd.get('etatCivil') === 'Marié(e)' ? (parseInt(fd.get('nombreEnfants'), 10) || 0) : 0,
    profession: fd.get('profession').trim(),
    eauPotable: switchValue('eauPotable'),
    electricite: switchValue('electricite'),
    internet: switchValue('internet'),
    elevage: switchValue('elevage'),
    animaux,
    hopitaux: switchValue('hopitaux'),
    marches: switchValue('marches'),
    gps: capturedGps,
    sync: navigator.onLine, // if online, we consider it synced immediately in this demo
    enqueteur: session ? session.username : 'inconnu'
  };

  const all = getRecords();
  all.push(record);
  saveRecords(all);

  surveyForm.reset();
  document.getElementById('enfantsField').hidden = true;
  document.getElementById('animauxField').hidden = true;
  document.getElementById('animauxList').innerHTML = '';
  document.querySelectorAll('.switch').forEach(sw => {
    sw.querySelectorAll('.switch__opt').forEach((o, i) => o.classList.toggle('is-active', i === 0));
  });
  document.querySelector('.switch[data-name="elevage"] .switch__opt[data-value="Non"]').classList.add('is-active');
  document.querySelector('.switch[data-name="elevage"] .switch__opt[data-value="Oui"]').classList.remove('is-active');
  capturedGps = null;
  gpsResult.textContent = 'Aucune position capturée.';
  gpsResult.classList.remove('is-set');

  refreshNetworkUI();
  toast(record.sync
    ? 'Fiche enregistrée et synchronisée.'
    : 'Fiche enregistrée localement — en attente de synchronisation.');

  if (!navigator.onLine){
    // stays pending
  }
});

function renderMyRecords(){
  const session = getSession();
  if (!session) return;
  const list = getRecords()
    .filter(r => r.enqueteur === session.username)
    .sort((a, b) => b.timestamp - a.timestamp);
  const container = document.getElementById('myRecordsList');
  if (list.length === 0){
    container.innerHTML = '<div class="empty-state">Aucune fiche enregistrée pour le moment.<br>Utilisez l\'onglet « Nouvelle fiche » pour commencer.</div>';
    return;
  }
  container.innerHTML = list.map(r => `
    <div class="record-stub">
      <div>
        <div class="record-stub__name">${escapeHtml(r.nomComplet)}</div>
        <div class="record-stub__meta">${r.id} · ${r.dateStr} · ${r.age} ans</div>
      </div>
      <span class="stamp ${r.sync ? 'stamp--synced' : 'stamp--pending'}">${r.sync ? 'SYNCHRONISÉ' : 'EN ATTENTE'}</span>
    </div>
  `).join('');
}

/* =========================================================
   6. DESKTOP — ADMIN DASHBOARD
   ========================================================= */
document.querySelectorAll('.sidebar__link').forEach(link => {
  link.addEventListener('click', () => {
    document.querySelectorAll('.sidebar__link').forEach(l => l.classList.remove('is-active'));
    link.classList.add('is-active');
    document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('is-active'));
    document.getElementById(`adminTab-${link.dataset.adminTab}`).classList.add('is-active');
  });
});

function refreshAdmin(){
  const records = getRecords();
  renderKpis(records);
  renderRecent(records);
  renderTable();
  renderSyncTab(records);
}

function renderKpis(records){
  const total = records.length;
  const synced = records.filter(r => r.sync).length;
  const pending = total - synced;
  const withWater = records.filter(r => r.eauPotable === 'Oui').length;
  const withElec = records.filter(r => r.electricite === 'Oui').length;
  const families = records.filter(r => r.etatCivil === 'Marié(e)' && r.nombreEnfants > 0).length;

  document.getElementById('kpiTotal').textContent = total;
  document.getElementById('kpiSyncRate').textContent = total ? Math.round((synced / total) * 100) + '%' : '0%';
  document.getElementById('kpiSyncDetail').textContent = `${synced} synchro / ${pending} en attente`;
  document.getElementById('kpiWater').textContent = total ? Math.round((withWater / total) * 100) + '%' : '0%';
  document.getElementById('kpiElec').textContent = total ? Math.round((withElec / total) * 100) + '%' : '0%';
  document.getElementById('kpiFamilies').textContent = families;
}

function renderRecent(records){
  const recent = [...records].sort((a, b) => b.timestamp - a.timestamp).slice(0, 6);
  const el = document.getElementById('recentList');
  if (recent.length === 0){
    el.innerHTML = '<div class="empty-state">Aucune fiche collectée pour l\'instant.</div>';
    return;
  }
  el.innerHTML = recent.map(r => `
    <div class="recent-row">
      <span>${escapeHtml(r.nomComplet)} <span class="recent-row__meta">— ${r.profession || 'profession non précisée'}</span></span>
      <span class="stamp ${r.sync ? 'stamp--synced' : 'stamp--pending'}">${r.sync ? 'SYNCHRONISÉ' : 'EN ATTENTE'}</span>
    </div>
  `).join('');
}

function renderSyncTab(records){
  const total = records.length;
  const synced = records.filter(r => r.sync).length;
  document.getElementById('syncTotal').textContent = total;
  document.getElementById('syncDone').textContent = synced;
  document.getElementById('syncPending').textContent = total - synced;
}

// ---- Data table: search, filter, sort ----
let sortState = { key: 'timestamp', dir: -1 };

function getFilteredRecords(){
  const q = document.getElementById('searchInput').value.trim().toLowerCase();
  const fSync = document.getElementById('filterSync').value;
  const fEtat = document.getElementById('filterEtatCivil').value;
  const fAge = document.getElementById('filterAge').value;

  let list = getRecords();

  if (q){
    list = list.filter(r =>
      r.nomComplet.toLowerCase().includes(q) ||
      (r.profession || '').toLowerCase().includes(q));
  }
  if (fSync){ list = list.filter(r => String(r.sync) === fSync); }
  if (fEtat){ list = list.filter(r => r.etatCivil === fEtat); }
  if (fAge){
    const [min, max] = fAge.split('-').map(Number);
    list = list.filter(r => r.age >= min && r.age <= max);
  }

  list.sort((a, b) => {
    let va = a[sortState.key], vb = b[sortState.key];
    if (typeof va === 'string') { va = va.toLowerCase(); vb = vb.toLowerCase(); }
    if (va < vb) return -1 * sortState.dir;
    if (va > vb) return 1 * sortState.dir;
    return 0;
  });

  return list;
}

function renderTable(){
  const list = getFilteredRecords();
  const tbody = document.getElementById('tableBody');
  const emptyMsg = document.getElementById('tableEmpty');

  if (list.length === 0){
    tbody.innerHTML = '';
    emptyMsg.hidden = false;
    return;
  }
  emptyMsg.hidden = true;

  tbody.innerHTML = list.map(r => `
    <tr>
      <td class="mono">${r.id}</td>
      <td class="mono">${r.dateStr}</td>
      <td>${escapeHtml(r.nomComplet)}</td>
      <td>${r.age}</td>
      <td>${escapeHtml(r.etatCivil || '—')}</td>
      <td>${escapeHtml(r.profession || '—')}</td>
      <td>
        <span class="tag ${r.eauPotable === 'Oui' ? 'tag--yes' : 'tag--no'}">Eau</span>
        <span class="tag ${r.electricite === 'Oui' ? 'tag--yes' : 'tag--no'}">Élec</span>
      </td>
      <td><span class="stamp ${r.sync ? 'stamp--synced' : 'stamp--pending'}">${r.sync ? 'SYNC' : 'ATTENTE'}</span></td>
      <td><button class="row-action" data-view="${r.id}">Détail</button></td>
    </tr>
  `).join('');

  tbody.querySelectorAll('[data-view]').forEach(btn => {
    btn.addEventListener('click', () => openDetailModal(btn.dataset.view));
  });
}

['searchInput', 'filterSync', 'filterEtatCivil', 'filterAge'].forEach(id => {
  document.getElementById(id).addEventListener('input', renderTable);
  document.getElementById(id).addEventListener('change', renderTable);
});

document.querySelectorAll('.data-table thead th[data-sort]').forEach(th => {
  th.addEventListener('click', () => {
    const key = th.dataset.sort;
    sortState.dir = (sortState.key === key) ? -sortState.dir : 1;
    sortState.key = key;
    renderTable();
  });
});

// ---- Detail modal ----
const detailModal = document.getElementById('detailModal');
document.getElementById('closeModalBtn').addEventListener('click', () => detailModal.hidden = true);
detailModal.addEventListener('click', (e) => { if (e.target === detailModal) detailModal.hidden = true; });

function openDetailModal(id){
  const r = getRecords().find(rec => rec.id === id);
  if (!r) return;
  const animauxStr = r.animaux && r.animaux.length
    ? r.animaux.map(a => `${escapeHtml(a.type)} (${a.quantite})`).join(', ')
    : 'Aucun';
  const gpsStr = r.gps ? `${r.gps.lat.toFixed(5)}, ${r.gps.lng.toFixed(5)}` : 'Non capturée';

  document.getElementById('modalBody').innerHTML = `
    <span class="stamp ${r.sync ? 'stamp--synced' : 'stamp--pending'}">${r.sync ? 'SYNCHRONISÉ' : 'EN ATTENTE'}</span>
    <h2>${escapeHtml(r.nomComplet)}</h2>
    <p class="settings-line" style="margin:0">${r.id} · Enregistrée le ${r.dateStr} par ${escapeHtml(r.enqueteur)}</p>
    <dl class="modal-grid">
      <div class="modal-grid__item"><dt>Âge</dt><dd>${r.age} ans</dd></div>
      <div class="modal-grid__item"><dt>État civil</dt><dd>${escapeHtml(r.etatCivil || '—')}</dd></div>
      <div class="modal-grid__item"><dt>Nom du père</dt><dd>${escapeHtml(r.pere || '—')}</dd></div>
      <div class="modal-grid__item"><dt>Nom de la mère</dt><dd>${escapeHtml(r.mere || '—')}</dd></div>
      <div class="modal-grid__item"><dt>Profession</dt><dd>${escapeHtml(r.profession || '—')}</dd></div>
      <div class="modal-grid__item"><dt>Nombre d'enfants</dt><dd>${r.nombreEnfants || 0}</dd></div>
      <div class="modal-grid__item"><dt>Eau potable</dt><dd>${r.eauPotable}</dd></div>
      <div class="modal-grid__item"><dt>Électricité</dt><dd>${r.electricite}</dd></div>
      <div class="modal-grid__item"><dt>Internet</dt><dd>${r.internet}</dd></div>
      <div class="modal-grid__item"><dt>Élevage</dt><dd>${r.elevage}</dd></div>
      <div class="modal-grid__item span-2"><dt>Animaux</dt><dd>${animauxStr}</dd></div>
      <div class="modal-grid__item"><dt>Hôpitaux à proximité</dt><dd>${r.hopitaux}</dd></div>
      <div class="modal-grid__item"><dt>Marchés à proximité</dt><dd>${r.marches}</dd></div>
      <div class="modal-grid__item span-2"><dt>Position GPS</dt><dd class="mono" style="font-family:var(--f-mono)">${gpsStr}</dd></div>
    </dl>
  `;
  detailModal.hidden = false;
}

// ---- Exports ----
document.getElementById('exportCsvBtn').addEventListener('click', () => {
  const list = getFilteredRecords();
  if (list.length === 0){ toast('Aucune donnée à exporter.', true); return; }
  const headers = ['id','dateStr','nom','prenom','age','pere','mere','etatCivil','nombreEnfants','profession',
    'eauPotable','electricite','internet','elevage','animaux','hopitaux','marches','gps','sync','enqueteur'];
  const rows = list.map(r => headers.map(h => {
    let v = r[h];
    if (h === 'animaux') v = (r.animaux || []).map(a => `${a.type}:${a.quantite}`).join('|');
    if (h === 'gps') v = r.gps ? `${r.gps.lat},${r.gps.lng}` : '';
    v = v === undefined || v === null ? '' : String(v);
    if (v.includes(',') || v.includes('"')) v = `"${v.replace(/"/g, '""')}"`;
    return v;
  }).join(','));
  const csv = [headers.join(','), ...rows].join('\n');
  downloadFile(csv, 'enquetes.csv', 'text/csv;charset=utf-8');
  toast(`${list.length} fiche(s) exportée(s) en CSV.`);
});

document.getElementById('exportJsonBtn').addEventListener('click', () => {
  const list = getFilteredRecords();
  if (list.length === 0){ toast('Aucune donnée à exporter.', true); return; }
  downloadFile(JSON.stringify(list, null, 2), 'enquetes.json', 'application/json');
  toast(`${list.length} fiche(s) exportée(s) en JSON.`);
});

function downloadFile(content, filename, mime){
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}

document.getElementById('clearDataBtn').addEventListener('click', () => {
  if (!confirm('Réinitialiser toutes les fiches locales de démonstration ?')) return;
  saveRecords([]);
  refreshAdmin();
  refreshNetworkUI();
  toast('Données de démonstration réinitialisées.');
});

/* =========================================================
   7. UTIL
   ========================================================= */
function escapeHtml(str){
  return String(str ?? '').replace(/[&<>"']/g, s => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[s]));
}

/* =========================================================
   8. INIT
   ========================================================= */
renderRoute();
